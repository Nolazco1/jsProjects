let num1 = 5;
let num2 = 6;
if (num1 >= num2) {
    document.write("<h1>The number " + num1 + " compared to " + num2 + " is greater than or equal to.</h1>");
} else {
    document.write("<h1>The number " + num1 + " compared to " + num2 + " is not greater than or equal to.</h1>");
}